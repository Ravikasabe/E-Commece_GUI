from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.ttk import Progressbar
import os 
import sys
import subprocess

root = Tk()
image =PhotoImage(file="loading-1.png")
height = 430
width=530
x=(root.winfo_screenwidth()//2)-(width//2)
y=(root.winfo_screenheight()//2)-(height//2)
root.geometry('{}x{}+{}+{}'.format(width, height,x , y))
root.overrideredirect(True)

root.config(background="#2F6C60")


bg_label=Label(root, image=image, bg="#2F6C60")
bg_label.place(x=60, y=25)

progress_label=Label(root, text="Loading...", font=("Trebuchet Ms", 13, "bold"),bg="#2F6C60",fg='white')
progress_label.place(x=190, y=330)

progress = ttk.Style()
progress.theme_use('clam')
progress.configure("red.Horizontal.TProgressbar", background="#108cff")
progress =Progressbar(root, orient=HORIZONTAL, length=400, mode='determinate', style="red.Horizontal.TProgressbar")
progress.place(x=60, y=370)



def login():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        
        os.system('home.py')
   
i=0  
def load():
    
    global i
  
    if i <= 10:
        txt = 'Loading...' + (str(10*i)+'%')
        progress_label.config(text=txt)
        progress_label.after(100,load)
        progress['value']=10*i
        i+=1
        
    else:
        login()


load()


root.resizable(False, False)
root.mainloop()