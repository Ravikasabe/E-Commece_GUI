from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import font as tkFont
import random 
import sys
from tkinter import messagebox
import os
import sqlite3

conn = sqlite3.connect('Users.db')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    email TEXT,
    password INTEGER
)
''')

generated_otp = None
def otp():
    global generated_otp
    generated_otp = random.randint(1000, 9999)
    print(generated_otp)
    messagebox.showinfo("OTP", f"Your OTP is: {generated_otp}")

def register():
    global generated_otp
    email = entry_email.get()
    password =  entry_pass.get()
    entered_otp = entry_otp.get()
    
    if not email or not password:
        messagebox.showerror("Error", "Email and password cannot be empty")
        return
    if not entered_otp:
        messagebox.showerror("Error", "Please enter the OTP")
        return
    
    if int(entered_otp) != generated_otp:
        messagebox.showerror("Error", "Invalid OTP")
        return
    conn = sqlite3.connect('Users.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Data inserted successfully!")
    if 'IPython' in sys.modules:
        root.destroy()
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
        print(True)
    else:
        os.system('register.py')

def login():
    if 'IPython' in sys.modules:
        root.destroy()
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
        print(True)
    else:
        os.system('register.py')
       
root = Tk()
root.title("Register Page")
root.geometry('1920x1080')

img_root = Image.open("reg_bg.jpg")
img_root = img_root.resize((1920, 1080), Image.LANCZOS)
img_root1 = ImageTk.PhotoImage(img_root)
label = tk.Label(root, image=img_root1)
label.place(x=0, y=0, relwidth=1, relheight=1)

stylfont = tkFont.Font(family="Helvetica", size=24, weight="bold", slant="italic")
title_label = tk.Label(root, text="Registration Form", height=1, width=1920, font=stylfont, background="#212F3D", fg="white", anchor='w',padx=100)
title_label.pack( padx=0, pady=5)
logout_button = tk.Button(root, font=('Arial', 10), text="Login", fg='black', bg="#E93B1C", width=6, command=login)
logout_button.place(x=1820, y=15)

form_image = Image.open("reg_bg_back.jpg")
form_image = form_image.resize((600, 700), Image.LANCZOS)
transparent_image = Image.new('RGBA', form_image.size, (63, 68, 69, 0))
blended_image = Image.blend(form_image.convert("RGBA"), transparent_image, alpha=0.2)
img_can = ImageTk.PhotoImage(blended_image)

canvas = tk.Canvas(root, width=blended_image.width, height=blended_image.height)
canvas.create_image(0, 0, anchor=tk.NW, image=img_can)
canvas.place(x=650, y=200)

entry = tk.Entry(canvas, width=26, font=("Helvetica", 14), bg="#717169",fg="white",justify='left')
entry.place(x=200, y=100)
name_label = tk.Label(canvas, text="Name ->", width=18, background="#F0EFA5", fg="black")
name_label.place( x=20, y=104)

entry = tk.Entry(canvas, width=20, font=("Helvetica", 14), bg="#717169",fg="white",justify='left')
entry.place(x=200, y=170)
Mobile_label = tk.Label(canvas, text="Mobile ->", width=18, background="#F0EFA5", fg="black")
Mobile_label.place(x=20, y=174)

entry_email = tk.Entry(canvas, width=26, font=("Helvetica", 14), bg="#717169",fg="white",justify='left')
entry_email.place(x=200, y=240)
email_Label = tk.Label(canvas, text="Email ->",  width=18, background="#F0EFA5", fg="black")
email_Label.place( x=20, y=244)

entry_pass = tk.Entry(canvas, width=26, font=("Helvetica", 14), bg="#717169",fg="white",justify='left')
entry_pass.place(x=200, y=310)
pass_label = tk.Label(canvas, text="Password ->", width=18, background="#F0EFA5", fg="black")
pass_label.place( x=20, y=314)

entry = tk.Entry(canvas, width=26, font=("Helvetica", 14), bg="#717169", fg="white", justify='left')
entry.place(x=200, y=380)
repass_label = tk.Label(canvas, text="Re-Enter Password ->", width=18, background="#F0EFA5", fg="black")
repass_label.place( x=20, y=384)

entry_otp = tk.Entry(canvas, width=10,  font=("Helvetica", 14), bg="#717169", fg="white", justify='left')
entry_otp.place(x=200, y=450)
otp_label = tk.Label(canvas, text="OTP ->", width=18, background="#F0EFA5", fg="black")
otp_label.place( x=20, y=454)

button = tk.Button(canvas, text="Register", font=("Helvetica", 10,'bold'), borderwidth=4, relief="sunken", width=8, bg="#72D46D", fg='#000000', command=register)
button.place(x=270, y=550)

button = tk.Button(canvas, text="Get OTP", font=("Helvetica", 10,'bold') , borderwidth=1, relief="sunken", bg="#72D46D",fg='#000000', command=otp)
button.place(x=500, y=169)

root.mainloop()
