import tkinter as tk
from tkinter import font as tkFont
from PIL import Image, ImageTk
import os
import sys
import sqlite3
from tkinter import messagebox

conn = sqlite3.connect('product_info.db')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS cart (cart_id INTEGER PRIMARY KEY AUTOINCREMENT,id INTEGER,name TEXT NOT NULL,price REAL NOT NULL,description TEXT NOT NULL,rating TEXT NOT NULL,image TEXT NOT NULL,quantity INTEGER NOT NULL)''')
conn.commit()
conn.close()

def copy_data():
    conn_source = sqlite3.connect('products.db')
    cursor_source = conn_source.cursor()
    cursor_source.execute("SELECT id, name, price, description, rating, image, quantity FROM products")
    products = cursor_source.fetchall()
    conn_source.close()
    conn_dest = sqlite3.connect('product_info.db')
    cursor_dest = conn_dest.cursor()
    cursor_dest.executemany("INSERT OR IGNORE INTO product_info (id, name, price, description, rating, image, quantity) VALUES (?, ?, ?, ?, ?, ?, ?)", products)
    conn_dest.commit()
    conn_dest.close()
copy_data()
print("Data copied successfully!")

def fetch_products():
    conn = sqlite3.connect('product_info.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, description, rating, image, quantity FROM product_info")
    db_products = cursor.fetchall()
    conn.close()
    return db_products

def on_configure(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

def back():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('details.py')

def home():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('login.py')

def show_details(product):
    for widget in details_frame.winfo_children():
        widget.destroy()
    name_label = tk.Label(details_frame, text=f"Name: {product[1]}", font=("Arial", 16), bg="#E1F5FE")
    name_label.pack(pady=10)

    description_label = tk.Label(details_frame, text=f"Description: {product[3]}", font=("Arial", 16), bg="#E1F5FE")
    description_label.pack(pady=10)

    img = Image.open(product[5])
    img = img.resize((300, 300), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)
    image_label = tk.Label(details_frame, image=photo, bg="#E1F5FE")
    image_label.image = photo 
    image_label.pack(pady=10)

def info(product):
    show_details(product)

root = tk.Tk()
root.title("Cart")
root.geometry("1920x1080")

stylfont = tkFont.Font(family="Helvetica", size=15, weight="bold", slant="italic")

title_label = tk.Label(root, text="Product Details", height=2, width=1920, font=stylfont, background="#212F3D", fg="white", anchor='w', padx=100)
title_label.pack(padx=0, pady=5)

back_button = tk.Button(title_label, font=('Arial', 10), text="Back", fg='white', bg="green", width=8, command=back)
back_button.place(x=1665, y=15)

home_button = tk.Button(title_label, font=('Arial', 10), text="Home", fg='white', bg="red", width=8, command=home)
home_button.place(x=1765, y=15)

products = fetch_products()

canvas = tk.Canvas(root, width=1000, height=900, bg="#898986")
canvas.pack(side='left', fill="both", expand=True)

scrollbar = tk.Scrollbar(canvas, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

content_frame = tk.Frame(canvas, bg='#D1BFDB')
content_frame.bind("<Configure>", on_configure)
canvas.create_window((0, 0), window=content_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

details_frame = tk.Frame(root, bg="#E1F5FE", width=0, height=0, relief='solid', borderwidth=3)
details_frame.place(x=1250, y=200)
#product_dict = {
#         "id":row[0],
#         "name": row[1],
#         "price": row[2],
#         "description": row[3],
#         "rating": f"{row[4]}/5",
#         "image": row[5],
#         "quantity":row[6]
#     }
products = fetch_products()

for product in products:
    frame = tk.Frame(content_frame, borderwidth=2, relief="groove", padx=10, pady=10, background='#95A5A6')
    frame.pack(pady=10, padx=10, fill='x')

    img = Image.open(product[5])
    img = img.resize((200, 200), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)
    image_label = tk.Label(frame, image=photo)
    image_label.image = photo
    image_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky='nw')

    name_label = tk.Label(frame, text=product[1], font=("Arial", 14, 'bold'), bg="#95A5A6")
    name_label.grid(row=0, column=1, sticky='w', padx=10, pady=5)

    price_label = tk.Label(frame, text=f"rs. {product[2]}", font=("Arial", 12), bg="#EC7063")
    price_label.grid(row=1, column=1, sticky='w', padx=10, pady=5)

    rating_label = tk.Label(frame, text=f"{product[4]}/5", font=("Arial", 12), fg="yellow", bg="#95A5A6")
    rating_label.grid(row=2, column=1, sticky='w', padx=10, pady=5)

    description_label = tk.Label(frame, text=product[3], font=("Arial", 12))
    description_label.grid(row=0, column=1, sticky='w', padx=300, pady=5)

    info_button = tk.Button(frame, font = 'bold',text="Get-Info", width=8, command=lambda p=product: info(p), bg="#5B5353", fg='white')
    info_button.place(x=620, y=100)

root.mainloop()
