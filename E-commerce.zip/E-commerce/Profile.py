from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk, ImageDraw
from tkinter import font as tkFont
from tkinter.filedialog import askopenfile as ask
import sys
import os  

def back():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('Profile.py')

def cart():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'cart.py')
    else:
        os.system('Profile.py')

def logout():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
    else:
        os.system('Profile.py')

def home():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('Profile.py')

def Help():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'help.py')
    else:
        os.system('Profile.py')

def details():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'details.py')
    else:
        os.system('Profile.py')

def create_oval_image(image_path, diameter):
    img = Image.open(image_path).resize((diameter, diameter), Image.LANCZOS)
    mask = Image.new('L', (diameter, diameter), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, diameter, diameter), fill=255)
    img.putalpha(mask)
    return img

def open_file():
    file = ask(mode="rb", filetypes=[('Image Files', '*.jpg;*.jpeg;*.png;*.gif;*.bmp')])
    if file is not None:
        return file.name

root = Tk()
root.title("Ravi's Shop")
root.geometry('1920x1080')

img_root = Image.open("profile.jpg")
img_root = img_root.resize((1920, 1080), Image.LANCZOS)
img_root1 = ImageTk.PhotoImage(img_root)
label = tk.Label(root, image=img_root1)
label.place(x=0, y=0, relwidth=1, relheight=1)

oval_diameter = 200

default_profile_image_path = "profile.jpg"
oval_img = create_oval_image(default_profile_image_path, oval_diameter)
oval_img_tk = ImageTk.PhotoImage(oval_img)

frame1 = tk.Frame(root, bg="#D6A9D8", height=400, width=650, relief='solid', borderwidth=3)
frame1.place(x=1200, y=150)

label1 = tk.Label(frame1, text="Name -", width=34, font=('Arial', 15, 'bold'), fg='black', bg="#D6A9D8", anchor='nw')
label1.place(x=20, y=20)

label2 = tk.Label(frame1, text="DOB -", width=34, font=('Arial', 15, 'bold'), fg='black', bg="#D6A9D8", anchor='nw')
label2.place(x=20, y=100)

label3 = tk.Label(frame1, text="Email -", width=34, font=('Arial', 15, 'bold'), fg='black', bg="#D6A9D8", anchor='nw')
label3.place(x=20, y=180)

label4 = tk.Label(frame1, text="Mobile - ", width=34, font=('Arial', 15, 'bold'), fg='black', bg="#D6A9D8", anchor='nw')
label4.place(x=20, y=260)

label5 = tk.Label(frame1, text="Address - ", width=34, font=('Arial', 15, 'bold'), fg='black', bg="#D6A9D8", anchor='nw')
label5.place(x=20, y=340)

def update_oval_image():
    global oval_img, oval_img_tk, profile_canvas
    image_path = open_file()
    if image_path:
        oval_img = create_oval_image(image_path, oval_diameter)
        oval_img_tk = ImageTk.PhotoImage(oval_img)
        profile_canvas.create_image(0, 0, anchor='nw', image=oval_img_tk)

btn = Button(frame1, bg="#EBDEF0", text='Select from Device', command=update_oval_image)
btn.place(x=480, y=240)

stylfont = tkFont.Font(family="Helvetica", size=10, weight="bold", slant="italic")

frame_main = tk.Frame(root, height=70, width=1920, background="#212F3D", padx=100)
frame_main.place(x=0, y=0)

title_label = tk.Label(frame_main, font=('Helvetica', 20, "bold"), text="Profile Page", bg="#212F3D", fg='white')
title_label.place(x=10, y=20)

home_button = tk.Button(frame_main, font=stylfont, text="Home", fg='white', bg="#2586DF", width=8, command=home)
home_button.place(x=1400, y=20)

help_button = tk.Button(frame_main, font=stylfont, text="Help", fg='white', bg="#2586DF", width=8, command=Help)
help_button.place(x=1500, y=20)

profile_button = tk.Button(frame_main, font=stylfont, text="Cart", fg='white', bg="#2586DF", width=8, command=cart)
profile_button.place(x=1600, y=20)

logout_button = tk.Button(frame_main, font=stylfont, text="Logout", fg='black', bg="#E93B1C", width=8, command=logout)
logout_button.place(x=1700, y=20)

profile_canvas = tk.Canvas(frame1, width=oval_diameter, height=oval_diameter, bg="#D6A9D8", highlightthickness=0)
profile_canvas.place(x=440, y=10)
profile_canvas.create_image(0, 0, anchor='nw', image=oval_img_tk)

frame2 = tk.Frame(root, bg="#AFD3DA", relief='solid', borderwidth=3)
frame2.place(x=100, y=150)

canvas = tk.Canvas(frame2, height=800, width=700, bg="#AFD3DA")
canvas.pack(side="left", fill="both", expand=True)

scrollbar = tk.Scrollbar(frame2, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

content_frame = tk.Frame(canvas, bg="#AFD3DA")
content_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

canvas.create_window((0, 0), window=content_frame, anchor="nw")

canvas.configure(yscrollcommand=scrollbar.set)

title_label = tk.Label(root, text="Orders", height=1, width=24, font=("Helvetica", 24, 'bold', "italic"), background="#212F3D", fg="white", anchor='w', padx=10)
title_label.place(x=100, y=99)

title_order = tk.Label(root, text="Details", height=1, width=22, font=("Helvetica", 24, 'bold', "italic"), background="#212F3D", fg="white", anchor='w', padx=20)
title_order.place(x=1200, y=99)

Order_List = [{'name': "Diabatic Care", 'total_amt': 'rs. 999/'},
              {'name': "Cholestelor Care", 'total_amt': 'rs. 1,750/'},
              {'name': "Wheete Grass", 'total_amt': 'rs. 8,870/'},
              {'name': "Fat Reduction", 'total_amt': 'rs. 9,209/'},
              {'name': "Diabatic Care", 'total_amt': 'rs. 999/'},
              {'name': "Cholestelor Care", 'total_amt': 'rs. 1,750/'},
              {'name': "Wheete Grass", 'total_amt': 'rs. 8,870/'},
              {'name': "Fat Reduction", 'total_amt': 'rs. 9,209/'},
              {'name': "Diabatic Care", 'total_amt': 'rs. 999/'},
              {'name': "Cholestelor Care", 'total_amt': 'rs. 1,750/'},
              {'name': "Wheete Grass", 'total_amt': 'rs. 8,870/'},
              {'name': "Fat Reduction", 'total_amt': 'rs. 9,209/'},
              ]

def add_sample_orders():
    for i, order in enumerate(Order_List):
        order_frame = tk.Frame(content_frame, bg="#AFD3DA")
        order_frame.pack(fill='x', pady=5)
        order_label = tk.Label(order_frame, text=f"Order {i + 1} - {order['name']}  - {order['total_amt']}", font=('Arial', 14), fg='black', bg="#AFD3DA", pady=20)
        order_label.pack(side="left", padx=10, pady=5)
        details_button = tk.Button(order_frame, text="Get Details", font=("Helvetica", 10, 'bold'), borderwidth=4, relief="sunken", width=8, bg="#3B3B3C", fg='white', command=details)
        details_button.pack(side="right", padx=150, pady=5)
add_sample_orders()

root.mainloop()
