from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import font as tkFont
import sys
import os
from tkinter import messagebox
import sqlite3
conn = sqlite3.connect('cart.db')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT NOT NULL,
    rating INTEGER NOT NULL,
    image TEXT NOT NULL,
    quantity INTEGER NOT NULL
)
''')
conn.commit()
conn.close()

def fetch_products():
    conn = sqlite3.connect('cart.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, description, rating, image, quantity FROM cart")
    db_products = cursor.fetchall()
    conn.close()
    return db_products

def on_configure(event):
    canvas.configure(scrollregion=canvas.bbox("all"))
    
def back():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('Profile.py')
        
def home():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('profile.py')
        
def info():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'details.py')
    else:
        os.system('Profile.py.py')       
        
def remove_product(Id):
    product_id = Id
    if not product_id:
        messagebox.showerror("Error", "Product ID must be provided")
        return

    try:
        product_id = int(product_id)
    except ValueError:
        messagebox.showerror("Error", "Product ID must be an integer")
        return
    conn = sqlite3.connect('cart.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM cart WHERE id=?", (product_id,))
    conn.commit()
    conn.close()
    if cursor.rowcount == 0:
        messagebox.showerror("Error", "Product ID not found")
    else:
        messagebox.showinfo("Success", "Product removed successfully!")
        #clear_entries()
        if 'IPython' in sys.modules:
            root.destroy()
            from IPython import get_ipython
            get_ipython().run_line_magic('run', 'edit_cart.py')
        else:
            os.system('edit_cart.py')
root = tk.Tk()
root.title("Cart")
root.geometry("1920x1080")

stylfont = tkFont.Font(family="Helvetica", size=15, weight="bold", slant="italic")

title_label = tk.Label(root, text="Cart", height=2, width=1920, font=stylfont, background="#212F3D", fg="white", anchor='w',padx=100)
title_label.pack( padx=0, pady=5)

back_button = tk.Button(title_label ,font=('Arial',10) ,  text="Back", fg='white',  bg="green", width=8, command=back)
back_button.place(x=1665,y=15)

Home_button = tk.Button(title_label ,font=('Arial',10) ,  text="Home", fg='white',  bg="red", width=8, command=home)
Home_button.place(x=1765,y=15)

canvas = tk.Canvas(root, width=1000, height=900, bg="#E8DBB7")
canvas.pack(side='left' ,fill="both", expand=True)

scrollbar = tk.Scrollbar(canvas, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")
content_frame = tk.Frame(canvas, bg='#D1BFDB')
content_frame.bind("<Configure>",on_configure)
canvas.create_window((0, 0), window=content_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)
# for row in rows:
#     product_dict = {
#         "id":row[0],
#         "name": row[1],
#         "price": row[2],
#         "description": row[3],
#         "rating": f"{row[4]}/5",
#         "image": row[5],
#         "quantity":row[6]
#}
products = fetch_products()
#print(products)
for product in products:

    frame = tk.Frame(content_frame, borderwidth=2, relief="groove", padx=10,pady=10, background='#95A5A6')
    frame.pack(pady=10, padx=10,fill='x')
    
    img = Image.open(product[5])
    img = img.resize((200, 200), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)
    image_label = tk.Label(frame,  image=photo)
    image_label.image = photo
    image_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky='nw')

    name_label = tk.Label(frame, text=product[1], font=("Arial", 14, 'bold'), bg="#95A5A6")
    name_label.grid(row=0, column=1, sticky='w', padx=10, pady=5)
   
    price_label = tk.Label(frame, text=f" rs. {product[2]}", font=("Arial", 12), bg="#EC7063")
    price_label.grid(row=1, column=1, sticky='w', padx=10, pady=5)

    rating_label = tk.Label(frame, text=f"{product[4]}/5", font=("Arial", 12), fg="#F9E79F", bg="#95A5A6")
    rating_label.grid(row=2, column=1, sticky='w', padx=10, pady=5)

    Discp_label = tk.Label(frame, text=product[3], font=("Arial", 12))
    Discp_label.grid(row=0, column=1, sticky='w', padx=300, pady=5)

    Info = tk.Button(frame, text="Get-Info", width=8, command=info ,bg="#D1C9BE", fg='blue')
    Info.place(x=620, y=100)

    remove_button = tk.Button(frame, text="Remove", width=15, borderwidth=4,bg="#F18A0A" ,command=lambda p=product[0]: remove_product(p))
    remove_button.grid(row=3, column=2, sticky='e', padx=0, pady=10)

final_price = sum(product[2] for product in products)
gst=final_price*5//100

Delivery_fee= 0
km=11
if km>10:
    Delivery_fee=50
else:
    Delivery_fee=0
total_price = final_price + gst + Delivery_fee

newframe=tk.Frame(root, height=700, width=500, bg="#34495E")
newframe.place(x=1290, y=150)

bg_image = Image.open("cart_bg.jpg")  # Update with your image path
bg_image = bg_image.resize((500, 700), Image.LANCZOS)  # Resize as needed
bg_photo = ImageTk.PhotoImage(bg_image)

bg_label = tk.Label(newframe, image=bg_photo)
bg_label.image = bg_photo
bg_label.place(relwidth=1, relheight=1)

total_price=tk.Label(newframe,text= f"Total Price - ₹. {total_price} ", fg= 'black',bg='#E67272',font=("Arial", 13), width=20, )
total_price.place(x=30, y=380)

new_canvas= tk.Canvas(newframe ,bg="#34495E")
new_canvas.place(x=28, y=30 )

for name in products:
    price_label = tk.Label(new_canvas, text=f"{name[1]}: ₹. {name[2]}", bg="#34495E", fg='white', font=("Arial", 12))
    price_label.pack(fill='y', padx=100)
    
price_label = tk.Label(new_canvas, text=f"GST/SGST: {gst}: \nDelivery Fee: ₹. {Delivery_fee}", bg="#34495E", fg='white', font=("Arial", 12))
price_label.pack(fill='y', padx=100)
    
button = tk.Button(newframe, text="Buy Now", borderwidth=4, relief="sunken", width=20, bg="#F39C12", command=home)
button.place(x=300, y=650)

root.mainloop()