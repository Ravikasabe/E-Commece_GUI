from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
import sys 
from tkinter import ttk
import os 

def logout():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
    else:
        os.system('help.py')

def home():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'home.py')
    else:
        os.system('help.py')

root = tk.Tk()
root.title("Product Listing")
root.geometry("1920x1080")

canvas1 = tk.Canvas(root, height=80, width=1920, bg="grey")
canvas1.place(x=0, y=0)

label1 = tk.Label(canvas1, text="Help", font=('arial', 24, 'bold'), bg="grey", fg="white")
label1.place(x=100, y=10)

logout_button = tk.Button(canvas1, font=('Arial', 10), text="Logout", fg='black', width=8, bg="#E93B1C", command=logout)
logout_button.place(x=1800, y=25)

home_button = tk.Button(canvas1, font=('Arial', 10), text="Home", fg='white', width=8, bg="green", command=home)
home_button.place(x=1690, y=25)

canvas2 = tk.Canvas(root, height=700, width=1920, bg="lightgrey")
canvas2.place(x=0, y=80)

img_root = Image.open("help_bg.png")
img_root = img_root.resize((1400, 700), Image.LANCZOS)
img_root1 = ImageTk.PhotoImage(img_root)
label = tk.Label(canvas2, image=img_root1)
label.place(x=0, y=0)

style = ttk.Style()
style.configure("Treeview", font=('Arial', 14), rowheight=40, background="#EBDEF0", foreground="black", fieldbackground="#E8DAEF")
style.configure("Treeview.Heading", font=('Arial', 18, 'bold'), background="#EBDEF0", foreground="black")

treeview_frame = tk.Frame(canvas2)
treeview_frame.place(x=1300, y=0, height=700, width=600) 

treeview = ttk.Treeview(treeview_frame, height=25)
treeview.heading('#0', text='Category')

treeview['columns'] = ('Category',)
treeview.column('#0', width=400)
treeview.column('Category', width=200)

items = [("Help", []),("Orders", ["Tracking Order", "Cancel Order", "Difficulty in Placing Order"]),("Home", ["Home Help", "Report Product"]),("Profile", ["Edit Profile", "Report Profile"]),("Transaction", ["Transaction Stuck", "Refund", "Other"]),("Other", ["write"]),]

for category, subitems in items:
    parent = treeview.insert('', 'end', text=category)
    for item in subitems:
        treeview.insert(parent, 'end', text=item)


treeview_scroll = ttk.Scrollbar(treeview_frame, orient="vertical", command=treeview.yview)
treeview.configure(yscrollcommand=treeview_scroll.set)
treeview_scroll.pack(side="right", fill="y")
treeview.pack(side="left", fill="both", expand=True)

canvas3 = tk.Canvas(root, height=300, width=1920, bg="grey")
canvas3.place(x=0, y=780)

label1 = tk.Label(canvas3, text="Contact -", font=('arial', 14, 'bold'), bg="grey", fg="white")
label1.place(x=100, y=10)

label2 = tk.Label(canvas3, text="Email - ecommerce@email.com", font=('arial', 12, 'bold'), bg="grey", fg="white")
label2.place(x=190, y=50)

label3 = tk.Label(canvas3, text="Phone - +91 8805333094", font=('arial', 12, 'bold'), bg="grey", fg="white")
label3.place(x=190, y=100)

label4 = tk.Label(canvas3, text="Whatsapp message - +91 8805333094", font=('arial', 12, 'bold'), bg="grey", fg="white")
label4.place(x=190, y=150)

label5 = tk.Label(canvas3, text="credits- @Ravi's Shop", font=('arial', 9, 'bold'), bg="grey", fg="#FDFEFE")
label5.place(x=1740, y=170)

root.mainloop()
