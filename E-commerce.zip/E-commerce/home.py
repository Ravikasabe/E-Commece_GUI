from tkinter import *
import tkinter as tk
from tkinter import messagebox
from PIL import Image , ImageTk
import sys 
import os
import sqlite3

conn = sqlite3.connect('cart.db')
cursor = conn.cursor()
cursor.execute("DROP TABLE IF EXISTS cart")
cursor.execute('''
CREATE TABLE cart (cart_id INTEGER PRIMARY KEY AUTOINCREMENT,id INTEGER,name TEXT NOT NULL,price REAL NOT NULL,description TEXT NOT NULL,rating TEXT NOT NULL,image TEXT NOT NULL,quantity INTEGER NOT NULL)''')
conn.commit()
conn.close()

def buy(product_name):
    messagebox.showinfo("Info", f"Bought {product_name}!")
    
def info():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'details.py')
    else:
        os.system('home.py')
    
def logout():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
    else:
        os.system('home.py')

def profile():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'Profile.py')
    else:
        os.system('home.py')  

def cart():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'cart.py')
    else:
        os.system('home.py')
        

def Help():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'help.py')
    else:
        os.system('home.py')
    
def add_to_cart(product_id):
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id=?", (product_id,))
    product = cursor.fetchone()
    conn.close()
    if product:
        conn_cart = sqlite3.connect('cart.db')
        cursor_cart = conn_cart.cursor()
        product_with_quantity = (*product[:-1], 1)
        cursor_cart.execute("INSERT INTO cart (id, name, price, description, rating, image, quantity) VALUES (?, ?, ?, ?, ?, ?, ?)", product_with_quantity)
        conn_cart.commit()
        conn_cart.close()
        messagebox.showinfo("Success", "Product added to cart successfully!")
    else:
        messagebox.showerror("Error", "Product not found")


def fetch_products():
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, description, rating, image, quantity FROM products")
    db_products = cursor.fetchall()
    conn.close()
    return db_products


root = tk.Tk()
root.title("Product Listing")
root.geometry("1920x1080")


frame1 = tk.Frame(root, height=60, width=1920, bg="#212F3D")
frame1.pack(fill="x")

title_label = tk.Label(frame1, height=1, font=('Helvetica', 13, 'bold'), text="Ravi's Shop", bg="#212F3D", fg="white")
title_label.pack(side="left", padx=50, pady=10)

button_frame = tk.Frame(frame1, bg="#212F3D")
button_frame.pack(side="right", padx=10, pady=10)

Home_button = tk.Button(button_frame, font=('Arial', 10), text="Home", fg='white', bg="#2586DF", width=8)
Home_button.pack(side="left", padx=5)

Info_button = tk.Button(button_frame, font=('Arial', 10), text="Cart", fg='white', bg="#2586DF", width=8,command=cart)
Info_button.pack(side="left", padx=5)

Help_button = tk.Button(button_frame, font=('Arial', 10), text="Help", fg='white', bg="#2586DF", width=8, command=Help)
Help_button.pack(side="left", padx=5)

profile_button = tk.Button(button_frame, font=('Arial', 10), text="Profile", fg='white', bg="#2586DF", width=8, command=profile)
profile_button.pack(side="left", padx=5)

logout_button = tk.Button(button_frame, font=('Arial', 10), text="Logout", fg='black', bg="#E93B1C", width=6, command=logout)
logout_button.pack(side="left", padx=45)


canvas = tk.Canvas(root, bg='#566573')
canvas.pack(side="left", fill="both", expand=True)
scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")
content_frame = tk.Frame(canvas, bg='#D1BFDB')
canvas.create_window((0, 0), window=content_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

def on_frame_configure(event):
    canvas.configure(scrollregion=canvas.bbox("all"))
content_frame.bind("<Configure>", on_frame_configure)

products = fetch_products()
# for row in rows:
#     product_dict = {
#         "id":row[0],
#         "name": row[1],
#         "price": row[2],
#         "description": row[3],
#         "rating": f"{row[4]}/5",
#         "image": row[5],
#         "quantity":row[6]
#     }
for product in products:
    frame = tk.Frame(content_frame,width=1000 ,borderwidth=2, relief="groove", padx=10, pady=10, background='#95A5A6')
    frame.pack(pady=5, padx=10, fill='x')

    img = Image.open(product[5])
    img = img.resize((200, 200), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)
    image_label = tk.Label(frame, image=photo)
    image_label.image = photo
    image_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky='nw')

    name_label = tk.Label(frame, text=product[1], font=("Arial", 14, 'bold'), background='#95A5A6', fg="#000000")
    name_label.grid(row=0, column=1, sticky='w', padx=10, pady=5)

    price_label = tk.Label(frame, text=product[2], font=("Arial", 12), bg="#EC7063")
    price_label.grid(row=1, column=1, sticky='w', padx=10, pady=5)

    rating_label = tk.Label(frame, text=product[4], font=("Arial", 12), fg="#F9E79F", bg="#95A5A6")
    rating_label.grid(row=2, column=1, sticky='w', padx=10, pady=5)

    Discp_label = tk.Label(frame, text=product[3], font=("Arial", 12), fg='black', bg='#93E0D1')
    Discp_label.grid(row=0, column=1, sticky='w', padx=280, pady=5)

    add_cart_button = tk.Button(frame, text="Add to Cart", width=15, borderwidth=4,command=lambda p=product[0]: add_to_cart(p), bg="#F18A0A")
    add_cart_button.grid(row=3, column=1, sticky='e', padx=10, pady=10)

    buy_button = tk.Button(frame, text="Buy", width=15, borderwidth=4, command=lambda p=product[1]: buy(p), bg="#F18A0A")
    buy_button.grid(row=3, column=1, sticky='e', padx=150, pady=10)

    Info = tk.Button(frame, text="Get-Info", width=8, command=info ,bg="#D1C9BE", fg='blue')
    Info.place(x=240, y=170)

canvas2 = tk.Canvas(root, borderwidth=2,  height=800, width=700)
canvas2.place(x=1150, y =150)

img_root = Image.open("offers.jpg")
img_root = img_root.resize((700, 800), Image.LANCZOS)
img_root1 = ImageTk.PhotoImage(img_root)
label = tk.Label(canvas2,  image=img_root1)
label.place(x=0, y=0, relwidth=1, relheight=1)

def show_offer_details(event):
    selected_index = listbox.curselection()
    if selected_index:
        selected_offer = listbox.get(selected_index)
        messagebox.showinfo("Offer Details", f"Details of the selected offer:\n{selected_offer}")

offers = [
    "Offer 1: 10% off on HDFC Credit Card",
    "\n",
    "Offer 2: Buy 1 Get 1 Free on select items",
    "\n",
    "Offer 3: 20% cashback on paytm UPI",
    "\n",
    "Offer 4: Free shipping on orders over 3999",
    "\n",
    "Offer 5: 50% off on your first purchase",
    "\n"
]

listbox = tk.Listbox(canvas2, selectmode=tk.SINGLE,bg="#EAE5ED", font="Arial",justify='left',width=50 , height=6, fg="#0018FF")
listbox.place(x=70, y=600)

for offer in offers:
    padded_offer = f"  {offer} "
    listbox.insert(tk.END, padded_offer, )

listbox.config(highlightthickness=10, bd=6, bg="#EAE5ED")
listbox.bind("<<ListboxSelect>>", show_offer_details)
btn=tk.Label(listbox, text="Scroll-Down",font=("Arial", 11,'bold'), bg="#EAE5ED").place(x=350,y=110)

root.mainloop()