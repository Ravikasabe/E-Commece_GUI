from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import font as tkFont
import sys
from tkinter import messagebox
import os
import sqlite3

conn = sqlite3.connect('Users.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY,email TEXT,password INTEGER)''')
conn.commit()
conn.close()

def add_placeholder(entry, placeholder):
    entry.insert(0, placeholder)
    entry.config(fg='black',justify='center')
    def on_focus_in(event):
        if entry.get() == placeholder:
            entry.delete(0, tk.END)
            entry.config(fg='black')
    def on_focus_out(event):
        if entry.get() == '':
            entry.insert(0, placeholder)
            entry.config(fg='black')
    entry.bind('<FocusIn>', on_focus_in)
    entry.bind('<FocusOut>', on_focus_out)


def login():
    email = entry_user.get()
    password = entry_pass.get()
    
    if not email or not password:
        messagebox.showerror("Error", "Email and password cannot be empty")
        return
    elif email=="Email" or password=="Password" :
        messagebox.showerror("Error", "Email and password cannot be empty")
        return
    elif email=="Admin@.in" and password =="1234":
        if 'IPython' in sys.modules:
            root.destroy()
            from IPython import get_ipython
            get_ipython().run_line_magic('run', 'Admin.py')
        else:
            os.system('login.py')
        
    else:
        conn = sqlite3.connect('Users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        result = cursor.fetchone()
        conn.close()
        if result:

            if 'IPython' in sys.modules:
                root.destroy()
                from IPython import get_ipython
                get_ipython().run_line_magic('run', 'Loading.py')
            else:
                os.system('login.py')
        else:
            messagebox.showerror("Error", "Invalid email or password")   

def reg():
    root.destroy()
    if 'IPython' in sys.modules: 
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'register.py')
    else:
        os.system('login.py')
    
root = Tk()
root.title("Ravi's Shop")
root.geometry('1920x1080')

img_root = Image.open("reg_bg.jpg")
img_root = img_root.resize((1920, 1080), Image.LANCZOS)
img_root1 = ImageTk.PhotoImage(img_root)
label = tk.Label(root, image=img_root1)
label.place(x=0, y=0, relwidth=1, relheight=1)

form_image = Image.open("reg_bg_back.jpg")
form_image = form_image.resize((650, 400), Image.LANCZOS)
transparent_image = Image.new('RGBA', form_image.size, (63, 68, 69, 0))
blended_image = Image.blend(form_image.convert("RGBA"), transparent_image, alpha=0.2)
img_can = ImageTk.PhotoImage(blended_image)

canvas = tk.Canvas(root, width=blended_image.width, height=blended_image.height)
canvas.create_image(0, 0, anchor=tk.NW, image=img_can)
canvas.place(x=660, y=280)

entry_user = tk.Entry(canvas, width=20, font=("Helvetica", 12,'bold'), bg="white")
entry_user.place(x=220, y=100)
add_placeholder(entry_user, "Email")

entry_pass = tk.Entry(canvas, width=20, font=("Helvetica", 12,'bold'), bg="white")
entry_pass.place(x=220, y=160)
add_placeholder(entry_pass, "Password")

button = tk.Button(canvas, text="Login",  font=("Helvetica", 9,'bold') ,borderwidth=4, relief="sunken",width=8, bg="#72D46D",fg='#000000', command=login)
button.place(x=224, y=230)

button = tk.Button(canvas, text="Register",font=("Helvetica", 9,'bold'), borderwidth=4, relief="sunken", width=8, bg="#72D46D", fg='#000000',command=reg)
button.place(x=350, y=230)

stylfont = tkFont.Font(family="Helvetica", size=24, weight="bold", slant="italic")
title_label = tk.Label(root, text="Login Page", height=2, width=10 , font=stylfont, background="#212F3D", fg="white",relief="solid", padx=720)
title_label.place(x=220, y=20)
image2=Image.open("main_logo.png")
image2=image2.resize((200, 150), Image.LANCZOS)
bd_image = ImageTk.PhotoImage(image2)
bd_label = tk.Label(root, image=bd_image)
bd_label.place(x=10, y=20)


root.mainloop()

