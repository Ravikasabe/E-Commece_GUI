import tkinter as tk
from tkinter import messagebox
import sqlite3
from tkinter import font as tkFont
import sys
import os
#  image": "C:/Users/RMK/OneDrive/Desktop/IT_Expert/E-commerce/p_image1.png

conn = sqlite3.connect('products.db')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT NOT NULL,
    rating INTEGER NOT NULL,
    image TEXT NOT NULL,
    quantity INTEGER NOT NULL
)
''')
conn.commit()
conn.close()
def add_product():
    name = name_entry.get()
    price = price_entry.get()
    quantity = quantity_entry.get()
    des = desc_entry.get()
    img = image_entry.get()
    rating = rating_entry.get()
    if not name or not price or not quantity:
        messagebox.showerror("Error", "All fields must be filled")
        return
    try:
        price = float(price)
        quantity = int(quantity)
    except ValueError:
        messagebox.showerror("Error", "Price must be a number and quantity must be an integer")
        return
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, price, quantity, description, image, rating) VALUES (?, ?, ?,?,?,?)", (name, price, quantity,des,img,rating))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Product added successfully!")
    clear_entries()
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'Admin.py')
    else:
        os.system('Admin.py')
def remove_product():
    product_id = id_entry.get()
    if not product_id:
        messagebox.showerror("Error", "Product ID must be provided")
        return
    try:
        product_id = int(product_id)
    except ValueError:
        messagebox.showerror("Error", "Product ID must be an integer")
        return
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id=?", (product_id,))
    conn.commit()
    conn.close()
    if cursor.rowcount == 0:
        messagebox.showerror("Error", "Product ID not found")
    else:
        messagebox.showinfo("Success", "Product removed successfully!")
    clear_entries()

def clear_entries():
    id_entry.delete(0, tk.END)
    name_entry.delete(0, tk.END)
    price_entry.delete(0, tk.END)
    quantity_entry.delete(0, tk.END)

def on_frame_configure(event):
    sc_canvas.configure(scrollregion=sc_canvas.bbox("all"))
    
def logout():
    root.destroy()
    if 'IPython' in sys.modules:
        from IPython import get_ipython
        get_ipython().run_line_magic('run', 'login.py')
    else:
        os.system('Admin.py')

root = tk.Tk()
root.title("Admin Product Management")
root.geometry("1920x1080") 
root.configure(background="#C0C1BD")

stylfont = tkFont.Font(family="Helvetica", size=26, weight="bold", slant="italic")
title_label = tk.Label(root, text="Admin Product details", font=stylfont ,height=2, anchor="w", width=300 ,  background="#212F3D", fg="white",relief="solid",padx=100)
title_label.place(x=0, y=5)

logout_button = tk.Button(title_label, font=('Arial', 10), text="Logout", fg='black', bg="#E93B1C", width=6, command=logout)
logout_button.place(x=1800, y=30)

canvas=tk.Canvas(root,bg="#D2C7A3", width=1000, height=800)
canvas.place(x=500,y=130)

tk.Label(canvas,width=10,font=("arial", 12),fg="#001AF5", bg ="#D2C7A3",text="Name:").place(x=80, y=101)
name_entry = tk.Entry(canvas,bg="#A3BDF0", fg="black", width=30, font=("arial", 15), relief="solid", border=3)
name_entry.place(x=220, y=100, )

tk.Label(canvas,width=10,font=("arial", 12),fg="#001AF5",bg ="#D2C7A3", text="Price:").place(x=80, y=201)
price_entry = tk.Entry(canvas,bg="#A3BDF0",  fg="black",width=20, font=("arial", 15),relief="solid", border=3)
price_entry.place(x=220, y=200)

tk.Label(canvas, width=10, fg="#001AF5",bg ="#D2C7A3",  font=("arial", 12),text="Quantity:").place(x=80, y=301)
quantity_entry = tk.Entry(canvas,bg="#A3BDF0" , fg="black", width=20, font=("arial", 15),relief="solid", border=3)
quantity_entry.place(x=220, y=300)

tk.Label(canvas,width=18,fg="#001AF5", bg ="#D2C7A3", font= 'bold',text="Rating out of 5:").place(x=550, y=201)
rating_entry = tk.Entry(canvas,bg="#A3BDF0" , width=16, fg="black",font=("arial", 15),relief="solid", border=3)
rating_entry.place(x=750, y=201)

tk.Label(canvas,width=18,fg="#001AF5", bg ="#D2C7A3", font= 'bold',text="Image Path:").place(x=540, y=301)
image_entry = tk.Entry(canvas,bg="#A3BDF0" ,width=16, fg="black", font=("arial", 15),relief="solid", border=3)
image_entry.place(x=750, y=301)

tk.Label(canvas,width=18,fg="#001AF5", bg ="#D2C7A3", font= 'bold',text="Description:").place(x=50, y=400)
desc_entry = tk.Entry(canvas, width=53,font=("arial", 15),bg="#A3BDF0" , fg="black",relief="solid", border=4)
desc_entry.place(x=220, y=400)

tk.Button(canvas, text="Add Product",bg="#64DE90", font='bold',fg="black",relief="solid", command=add_product).place(x=500, y=520)

tk.Label(canvas,width=18,fg="#001AF5", bg ="#D2C7A3", font= 'bold',text="Product ID to remove:").place(x=80, y=702)
id_entry = tk.Entry(canvas, width=14, bg="#A3BDF0" , fg="black", font=("arial", 15),relief="solid", border=3)
id_entry.place(x=290, y=702)

tk.Button(canvas, text="Remove Product",bg="#E36A6A", fg="white", command=remove_product).place(x=550, y=702)

sc_frame=tk.Frame(root ,width=430, height=800)
sc_frame.place(x=10,y=130)

sc_canvas=tk.Canvas(sc_frame ,width=430, height=800, bg="#E5D6D6")
sc_canvas.pack(side="left", fill="both", expand=True)
v_scrollbar = tk.Scrollbar(sc_frame, orient="vertical", command=sc_canvas.yview)
v_scrollbar.pack(side="right", fill="y")
h_scrollbar = tk.Scrollbar(sc_frame, orient="horizontal", command=sc_canvas.xview)
h_scrollbar.pack(side="bottom", fill="x")
sc_canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
scrollable_frame = tk.Frame(sc_canvas, bg="white")
sc_canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
scrollable_frame.bind("<Configure>", on_frame_configure)

products=[]
conn = sqlite3.connect('products.db')
cursor = conn.cursor()
cursor.execute("SELECT  name, price, description, rating, image FROM products")
rows = cursor.fetchall()
conn.close()
for row in rows:
    product_dict = {
        "name": row[0],
        "price": row[1],
        "description": row[2],
        "rating": f"{row[3]}/5",
        "image": row[4]
    }
    products.append(product_dict)
num=1
for i in products:
    tk.Label(scrollable_frame, anchor='w',  font=("Arial",15,"bold"),fg='black', bg="#E5D6D6", width=29, text=f" ID:  {num}   ->   {i['name']}").pack()
    num+=1
    
root.mainloop()
